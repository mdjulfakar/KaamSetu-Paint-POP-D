package com.kaamsetu.app

import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { KaamSetuApp() }
    }
}

@Composable
fun KaamSetuApp() {
    var screen by remember { mutableStateOf("home") }
    var selectedPhoto by remember { mutableStateOf<Uri?>(null) }
    val photoPicker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        selectedPhoto = uri
    }

    MaterialTheme {
        Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
            when (screen) {
                "booking" -> EntryForm(
                    title = "काम बुक करें",
                    subtitle = "अपनी जरूरत बताएँ। हमारी टीम आपसे संपर्क करेगी।",
                    buttonText = "बुकिंग जमा करें",
                    photoUri = selectedPhoto,
                    onPickPhoto = { photoPicker.launch("image/*") },
                    onBack = { screen = "home"; selectedPhoto = null }
                )
                "adminLogin" -> AdminLoginScreen(onBack = { screen = "home" }, onLogin = { screen = "adminDashboard" })
                "adminDashboard" -> AdminDashboardScreen(onBack = { screen = "home" })
                "artisan" -> EntryForm(
                    title = "कारीगर रजिस्ट्रेशन",
                    subtitle = "अपना हुनर, काम का इलाका और काम की फोटो जोड़ें।",
                    buttonText = "रजिस्ट्रेशन जमा करें",
                    photoUri = selectedPhoto,
                    onPickPhoto = { photoPicker.launch("image/*") },
                    onBack = { screen = "home"; selectedPhoto = null }
                )
                else -> HomeScreen(
                    onBooking = { selectedPhoto = null; screen = "booking" },
                    onArtisan = { selectedPhoto = null; screen = "artisan" },
                    onAdmin = { screen = "adminLogin" }
                )
            }
        }
    }
}

@Composable
fun HomeScreen(onBooking: () -> Unit, onArtisan: () -> Unit, onAdmin: () -> Unit) {
    Column(
        modifier = Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(22.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Text("KaamSetu", style = MaterialTheme.typography.displaySmall,
            fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
        Spacer(Modifier.height(6.dp))
        Text("काम मिले, हुनर आगे बढ़े", style = MaterialTheme.typography.titleMedium)
        Spacer(Modifier.height(10.dp))
        Text("जम्मू-कश्मीर में भरोसेमंद POP और पेंटिंग सेवाएँ",
            style = MaterialTheme.typography.bodyMedium)
        Spacer(Modifier.height(28.dp))
        Button(onClick = onBooking, modifier = Modifier.fillMaxWidth().height(54.dp),
            shape = RoundedCornerShape(14.dp)) { Text("काम बुक करें") }
        Spacer(Modifier.height(12.dp))
        OutlinedButton(onClick = onArtisan, modifier = Modifier.fillMaxWidth().height(54.dp),
            shape = RoundedCornerShape(14.dp)) { Text("कारीगर रजिस्ट्रेशन") }
        Spacer(Modifier.height(8.dp))
        TextButton(onClick = onAdmin) { Text("Admin Login") }
        Spacer(Modifier.height(28.dp))
        Text("हमारी सेवाएँ", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(10.dp))
        listOf("POP डिजाइन", "पेंटिंग", "पुट्टी", "पॉलिश / फिनिशिंग").forEach {
            Card(Modifier.fillMaxWidth().padding(vertical = 4.dp)) {
                Text(it, Modifier.padding(16.dp), style = MaterialTheme.typography.titleMedium)
            }
        }
        Spacer(Modifier.height(20.dp))
        Text("शुरुआती ऐप संस्करण • ग्राहक और कारीगर फॉर्म",
            style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun EntryForm(
    title: String,
    subtitle: String,
    buttonText: String,
    photoUri: Uri?,
    onPickPhoto: () -> Unit,
    onBack: () -> Unit
) {
    var name by remember { mutableStateOf("") }
    var phone by remember { mutableStateOf("") }
    var district by remember { mutableStateOf("श्रीनगर") }
    var area by remember { mutableStateOf("") }
    var work by remember { mutableStateOf("POP डिजाइन") }
    var details by remember { mutableStateOf("") }
    var submitted by remember { mutableStateOf(false) }
    var expanded by remember { mutableStateOf(false) }
    val districts = listOf(
        "श्रीनगर", "अनंतनाग", "बारामूला", "बडगाम", "कुपवाड़ा", "पुलवामा", "शोपियां",
        "गांदरबल", "बांदीपोरा", "कुलगाम", "जम्मू", "सांबा", "कठुआ", "उधमपुर",
        "रियासी", "डोडा", "किश्तवाड़", "रामबन", "राजौरी", "पुंछ", "अन्य"
    )
    val works = listOf("POP डिजाइन", "पेंटिंग", "पुट्टी", "पॉलिश")

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(20.dp)) {
        TextButton(onClick = onBack) { Text("← वापस") }
        Text(title, style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
        Text(subtitle, style = MaterialTheme.typography.bodyMedium)
        Spacer(Modifier.height(16.dp))
        OutlinedTextField(name, { name = it; submitted = false }, label = { Text("पूरा नाम") },
            modifier = Modifier.fillMaxWidth(), singleLine = true)
        OutlinedTextField(phone, { phone = it.filter(Char::isDigit).take(10); submitted = false },
            label = { Text("मोबाइल नंबर") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
            modifier = Modifier.fillMaxWidth(), singleLine = true)
        Spacer(Modifier.height(8.dp))
        Text("जिला", fontWeight = FontWeight.SemiBold)
        ExposedDropdownMenuBox(expanded = expanded, onExpandedChange = { expanded = !expanded }) {
            OutlinedTextField(district, {}, readOnly = true, label = { Text("जिला चुनें") },
                trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded) },
                modifier = Modifier.menuAnchor().fillMaxWidth())
            ExposedDropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }) {
                districts.forEach { item ->
                    DropdownMenuItem(text = { Text(item) }, onClick = { district = item; expanded = false })
                }
            }
        }
        OutlinedTextField(area, { area = it; submitted = false }, label = { Text("इलाका / पता") },
            modifier = Modifier.fillMaxWidth())
        Spacer(Modifier.height(8.dp))
        Text("काम का प्रकार", fontWeight = FontWeight.SemiBold)
        works.forEach { item ->
            Row(verticalAlignment = Alignment.CenterVertically) {
                RadioButton(selected = work == item, onClick = { work = item })
                Text(item)
            }
        }
        OutlinedTextField(details, { details = it; submitted = false },
            label = { Text("काम की जानकारी / अनुभव") }, minLines = 3, modifier = Modifier.fillMaxWidth())
        Spacer(Modifier.height(12.dp))
        OutlinedButton(onClick = onPickPhoto, modifier = Modifier.fillMaxWidth()) {
            Text(if (photoUri == null) "गैलरी से फोटो चुनें" else "दूसरी फोटो चुनें")
        }
        if (photoUri != null) {
            Text("फोटो चुनी गई: ${photoUri.lastPathSegment ?: "Image"}",
                style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.primary)
        }
        Spacer(Modifier.height(16.dp))
        Button(
            onClick = { submitted = true },
            enabled = name.isNotBlank() && phone.length == 10 && area.isNotBlank(),
            modifier = Modifier.fillMaxWidth()
        ) { Text(buttonText) }
        if (submitted) {
            Spacer(Modifier.height(12.dp))
            Text("फॉर्म की जानकारी तैयार है। अभी इसे ऑनलाइन भेजने के लिए सर्वर कनेक्शन जोड़ना बाकी है।",
                color = MaterialTheme.colorScheme.primary)
        }
        Spacer(Modifier.height(16.dp))
        Text("अभी फोटो फोन से चुनी जा सकती है। सुरक्षित ऑनलाइन सेव, Admin पैनल, कारीगर को काम भेजना और WhatsApp अपडेट अगले चरण में जुड़ेंगे।",
            style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}


@Composable
fun AdminLoginScreen(onBack: () -> Unit, onLogin: () -> Unit) {
    var pin by remember { mutableStateOf("") }
    var error by remember { mutableStateOf(false) }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(22.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
        TextButton(onClick = onBack, modifier = Modifier.align(Alignment.Start)) { Text("← वापस") }
        Text("Admin Login", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
        Text("डेमो एडमिन पैनल खोलने के लिए PIN डालें")
        Spacer(Modifier.height(16.dp))
        OutlinedTextField(value = pin, onValueChange = { pin = it.filter(Char::isDigit).take(6); error = false }, label = { Text("6 अंकों का Demo PIN") }, singleLine = true, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword), modifier = Modifier.fillMaxWidth())
        if (error) Text("PIN सही नहीं है। Demo PIN 123456 है।", color = MaterialTheme.colorScheme.error)
        Spacer(Modifier.height(12.dp))
        Button(onClick = { if (pin == "123456") onLogin() else error = true }, enabled = pin.length == 6, modifier = Modifier.fillMaxWidth()) { Text("लॉगिन करें") }
        Spacer(Modifier.height(12.dp))
        Text("यह केवल UI डेमो PIN है। असली ऐप में सुरक्षित ऑनलाइन Admin Authentication जरूरी है।", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}

@Composable
fun AdminDashboardScreen(onBack: () -> Unit) {
    var tab by remember { mutableStateOf("बुकिंग") }
    val tabs = listOf("बुकिंग", "कारीगर", "सेटिंग")
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(20.dp)) {
        TextButton(onClick = onBack) { Text("← होम पर जाएँ") }
        Text("Admin Dashboard", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
        Text("KaamSetu • प्रबंधन पैनल", color = MaterialTheme.colorScheme.onSurfaceVariant)
        Spacer(Modifier.height(16.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf("कुल बुकिंग" to "0", "कारीगर" to "0", "नए काम" to "0").forEach { item ->
                Card(Modifier.weight(1f)) { Column(Modifier.padding(10.dp)) { Text(item.first, style = MaterialTheme.typography.bodySmall); Text(item.second, style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold) } }
            }
        }
        Spacer(Modifier.height(16.dp))
        SingleChoiceSegmentedButtonRow(Modifier.fillMaxWidth()) {
            tabs.forEachIndexed { i, value -> SegmentedButton(selected = tab == value, onClick = { tab = value }, shape = SegmentedButtonDefaults.itemShape(index = i, count = tabs.size)) { Text(value) } }
        }
        Spacer(Modifier.height(14.dp))
        when (tab) {
            "बुकिंग" -> DashboardInfo("बुकिंग प्रबंधन", "अभी कोई लाइव बुकिंग उपलब्ध नहीं है। ग्राहक फॉर्म को डेटाबेस से जोड़ने के बाद यहाँ बुकिंग दिखेगी।")
            "कारीगर" -> DashboardInfo("कारीगर प्रबंधन", "अभी कोई लाइव कारीगर रजिस्ट्रेशन उपलब्ध नहीं है। Backend जुड़ने पर Approve / Reject और काम Assign करने के विकल्प आएँगे।")
            else -> DashboardInfo("ऐप सेटिंग", "सेवा क्षेत्र: जम्मू-कश्मीर\nसेवाएँ: POP, पेंटिंग, पुट्टी, पॉलिश\nअगला चरण: सुरक्षित डेटाबेस और फोटो स्टोरेज\nWhatsApp अपडेट: अभी कनेक्ट नहीं")
        }
        Spacer(Modifier.height(16.dp))
        Text("यह Dashboard अभी फ्रंटएंड प्रोटोटाइप है। वास्तविक बुकिंग, कारीगर डेटा, असाइनमेंट और लॉगिन सुरक्षा के लिए backend अगला जरूरी चरण है।", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}

@Composable
private fun DashboardInfo(title: String, message: String) {
    Text(title, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
    Spacer(Modifier.height(8.dp))
    Card(Modifier.fillMaxWidth()) { Text(message, Modifier.padding(16.dp)) }
}
