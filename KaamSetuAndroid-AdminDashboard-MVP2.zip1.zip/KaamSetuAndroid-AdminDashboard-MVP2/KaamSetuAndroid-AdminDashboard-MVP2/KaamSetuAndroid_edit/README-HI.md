# KaamSetu Android — शुरुआती कार्यशील UI

**ऐप:** KaamSetu — काम मिले, हुनर आगे बढ़े  
**सेवाएँ:** POP डिजाइन, पेंटिंग, पुट्टी और पॉलिश  
**क्षेत्र:** जम्मू-कश्मीर के 20 जिले और “अन्य” विकल्प  
**पैकेज:** `com.kaamsetu.app`

## इस संस्करण में
- होम स्क्रीन और ग्राहक बुकिंग फॉर्म
- कारीगर रजिस्ट्रेशन फॉर्म
- Admin Login स्क्रीन (डेमो PIN: `123456`)
- Admin Dashboard UI: बुकिंग, कारीगर और सेटिंग टैब
- 20 जिलों की सूची
- मोबाइल नंबर का 10 अंकों का बेसिक validation
- फोन की गैलरी से फोटो चुनने का Android Photo Picker flow
- GitHub Actions से debug APK बनाने की workflow

## अभी production-ready नहीं है
यह UI milestone है, लाइव सेवा नहीं। अभी फॉर्म केवल स्क्रीन पर तैयार होते हैं; डेटा सर्वर पर सेव नहीं होता। सुरक्षित Admin authentication, database, सुरक्षित फोटो storage, worker approval/assignment, worker accept/reject/completion updates, WhatsApp integration, OTP और privacy/security rules अगले backend milestone में जोड़ने होंगे। Admin Dashboard अभी केवल UI प्रोटोटाइप है; इसमें लाइव डेटा नहीं आता। Demo PIN `123456` सुरक्षित लॉगिन नहीं है और इसे production में उपयोग न करें। सार्वजनिक स्क्रीन पर ग्राहक का फोन या पूरा पता नहीं दिखाया जाएगा।

## GitHub पर
Repository का सुझाया नाम `KaamSetuAndroid` है। ZIP extract करके पूरे `KaamSetuAndroid` folder की सामग्री private GitHub repository में डालें। `main` branch पर push होने पर `.github/workflows/build-android.yml` debug APK बनाएगी और `KaamSetu-debug-apk` artifact देगी।

यह debug APK केवल परीक्षण के लिए होगा; Play Store release के लिए signing, privacy policy, data safety और release testing बाकी हैं।
